var searchData=
[
  ['num_5fof_5fsol_0',['num_of_sol',['../structeq__solve__t.html#a301a2b3694e46c825371e4e36a588ba0',1,'eq_solve_t']]]
];
