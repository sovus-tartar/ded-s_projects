var searchData=
[
  ['sq_5feq_5fcoef_0',['sq_eq_coef',['../kvadr__func_8h.html#a6cc22e2c29928f6e515ffe82507aeecc',1,'kvadr_func.h']]]
];
