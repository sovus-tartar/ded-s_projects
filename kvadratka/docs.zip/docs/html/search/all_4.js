var searchData=
[
  ['input_5fcoefficients_0',['input_coefficients',['../kvadr__func_8h.html#a66aa6b74d93d34cdf533dc2373d0a82b',1,'input_coefficients(sq_eq_coef *coef):&#160;kvadr_func.c'],['../kvadr__func_8c.html#a0fa0fdea4002eb78e38c0d1e8fe5ada9',1,'input_coefficients(sq_eq_coef *coefficients):&#160;kvadr_func.c']]],
  ['input_5fsolves_1',['input_solves',['../kvadr__func_8h.html#ad4998a8d8a291e6e27e8950515d30fa9',1,'input_solves(eq_solve *solve):&#160;test.c'],['../test_8c.html#ad4998a8d8a291e6e27e8950515d30fa9',1,'input_solves(eq_solve *solve):&#160;test.c']]],
  ['is_5fequal_2',['is_equal',['../kvadr__func_8h.html#a5cf9cf5e86c145a2bc103e94d0eb54db',1,'is_equal(double num1, double num2):&#160;kvadr_func.c'],['../kvadr__func_8c.html#a5cf9cf5e86c145a2bc103e94d0eb54db',1,'is_equal(double num1, double num2):&#160;kvadr_func.c']]],
  ['is_5fequal_5fsolves_3',['is_equal_solves',['../kvadr__func_8h.html#a904999fc41cf77e2dca6b07fc8a9f934',1,'is_equal_solves(eq_solve solve1, eq_solve solve2):&#160;test.c'],['../test_8c.html#a904999fc41cf77e2dca6b07fc8a9f934',1,'is_equal_solves(eq_solve solve1, eq_solve solve2):&#160;test.c']]]
];
