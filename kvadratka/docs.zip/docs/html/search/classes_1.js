var searchData=
[
  ['sq_5feq_5fcoef_5ft_0',['sq_eq_coef_t',['../structsq__eq__coef__t.html',1,'']]]
];
