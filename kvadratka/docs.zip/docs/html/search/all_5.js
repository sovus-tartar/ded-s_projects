var searchData=
[
  ['kvadr_5ffunc_2ec_0',['kvadr_func.c',['../kvadr__func_8c.html',1,'']]],
  ['kvadr_5ffunc_2eh_1',['kvadr_func.h',['../kvadr__func_8h.html',1,'']]]
];
