var searchData=
[
  ['square_20equations_20solver_0',['Square equations solver',['../md_readme.html',1,'']]]
];
