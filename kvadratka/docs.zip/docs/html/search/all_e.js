var searchData=
[
  ['x1_0',['x1',['../structeq__solve__t.html#a1ac932f2ae09110128769c5b2e7e58f3',1,'eq_solve_t']]],
  ['x2_1',['x2',['../structeq__solve__t.html#ad551526f4c4601c7788079cbd5483d74',1,'eq_solve_t']]]
];
