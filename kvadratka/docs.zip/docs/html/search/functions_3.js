var searchData=
[
  ['solve_5flinear_5fequation_0',['solve_linear_equation',['../kvadr__func_8h.html#a88da85a42002884aeb220f89dc25b19c',1,'solve_linear_equation(sq_eq_coef coefficients, eq_solve *solves):&#160;kvadr_func.c'],['../kvadr__func_8c.html#a88da85a42002884aeb220f89dc25b19c',1,'solve_linear_equation(sq_eq_coef coefficients, eq_solve *solves):&#160;kvadr_func.c']]],
  ['solve_5fsquare_5fequation_1',['solve_square_equation',['../kvadr__func_8h.html#a6f92e9215b9e233e359521c8efc7a20a',1,'solve_square_equation(sq_eq_coef coefficients, eq_solve *solves):&#160;kvadr_func.c'],['../kvadr__func_8c.html#a6f92e9215b9e233e359521c8efc7a20a',1,'solve_square_equation(sq_eq_coef coefficients, eq_solve *solves):&#160;kvadr_func.c']]]
];
