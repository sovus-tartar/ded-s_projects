var searchData=
[
  ['unit_5ftest_0',['unit_test',['../kvadr__func_8h.html#ae9b06a4e5b4aa1e99fb27bd47b1209ba',1,'unit_test():&#160;test.c'],['../test_8c.html#ae9b06a4e5b4aa1e99fb27bd47b1209ba',1,'unit_test():&#160;test.c']]],
  ['user_5finterface_1',['user_interface',['../kvadr__func_8h.html#a09d10938e74c22e7334c7ef14cd36f82',1,'user_interface():&#160;kvadr_func.c'],['../kvadr__func_8c.html#a09d10938e74c22e7334c7ef14cd36f82',1,'user_interface():&#160;kvadr_func.c']]]
];
