var searchData=
[
  ['solve_5flinear_5fequation_0',['solve_linear_equation',['../kvadr__func_8h.html#a88da85a42002884aeb220f89dc25b19c',1,'solve_linear_equation(sq_eq_coef coefficients, eq_solve *solves):&#160;kvadr_func.c'],['../kvadr__func_8c.html#a88da85a42002884aeb220f89dc25b19c',1,'solve_linear_equation(sq_eq_coef coefficients, eq_solve *solves):&#160;kvadr_func.c']]],
  ['solve_5fsquare_5fequation_1',['solve_square_equation',['../kvadr__func_8h.html#a6f92e9215b9e233e359521c8efc7a20a',1,'solve_square_equation(sq_eq_coef coefficients, eq_solve *solves):&#160;kvadr_func.c'],['../kvadr__func_8c.html#a6f92e9215b9e233e359521c8efc7a20a',1,'solve_square_equation(sq_eq_coef coefficients, eq_solve *solves):&#160;kvadr_func.c']]],
  ['sq_5feq_5fcoef_2',['sq_eq_coef',['../kvadr__func_8h.html#a6cc22e2c29928f6e515ffe82507aeecc',1,'kvadr_func.h']]],
  ['sq_5feq_5fcoef_5ft_3',['sq_eq_coef_t',['../structsq__eq__coef__t.html',1,'']]],
  ['square_20equations_20solver_4',['Square equations solver',['../md_readme.html',1,'']]]
];
