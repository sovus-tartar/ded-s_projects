var searchData=
[
  ['b_0',['b',['../structsq__eq__coef__t.html#a7285e8cb28a1ed4903a818c1b352d938',1,'sq_eq_coef_t']]]
];
