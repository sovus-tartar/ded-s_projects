var searchData=
[
  ['ok_0',['OK',['../kvadr__func_8h.html#abfd51332ef0e0ba71f951a69e68e06bea2bc49ec37d6a5715dd23e85f1ff5bb59',1,'kvadr_func.h']]]
];
