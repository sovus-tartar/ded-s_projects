var searchData=
[
  ['print_5fcoefficients_0',['print_coefficients',['../test_8c.html#ae6fe45afb981c50808802b75f8b55547',1,'test.c']]],
  ['print_5fdescription_1',['print_description',['../kvadr__func_8h.html#acaf1dcea7c3c52a8f66f1f7f241f9912',1,'print_description():&#160;kvadr_func.c'],['../kvadr__func_8c.html#acaf1dcea7c3c52a8f66f1f7f241f9912',1,'print_description():&#160;kvadr_func.c']]],
  ['print_5fsolves_2',['print_solves',['../kvadr__func_8h.html#acc2a968a69494b3aa558b41e5586acaa',1,'print_solves(eq_solve solves):&#160;kvadr_func.c'],['../kvadr__func_8c.html#acc2a968a69494b3aa558b41e5586acaa',1,'print_solves(eq_solve solves):&#160;kvadr_func.c']]]
];
